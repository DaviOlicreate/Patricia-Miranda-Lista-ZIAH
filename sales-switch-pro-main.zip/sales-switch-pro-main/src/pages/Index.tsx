import HeroSection from "@/components/HeroSection";
import VideoSection from "@/components/VideoSection";
import MarqueeSection from "@/components/MarqueeSection";
import ProgramSection from "@/components/ProgramSection";
import IncludesSection from "@/components/IncludesSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import SpeakersSection from "@/components/SpeakersSection";
import PillarsSection from "@/components/PillarsSection";
import PricingSection from "@/components/PricingSection";
import LocationSection from "@/components/LocationSection";
import FaqSection from "@/components/FaqSection";
import FinalCtaSection from "@/components/FinalCtaSection";
import Footer from "@/components/Footer";
import WhatsappFloat from "@/components/WhatsappFloat";

const Index = () => {
  return (
    <div className="min-h-screen">
      <HeroSection />
      <VideoSection />
      <MarqueeSection />
      <ProgramSection />
      <IncludesSection />
      <TestimonialsSection />
      <SpeakersSection />
      <PillarsSection />
      <PricingSection />
      <LocationSection />
      <FinalCtaSection />
      <FaqSection />
      <Footer />
      <WhatsappFloat />
    </div>
  );
};

export default Index;
