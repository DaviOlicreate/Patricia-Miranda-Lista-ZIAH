import CtaButton from "./CtaButton";
import { motion } from "framer-motion";

const FinalCtaSection = () => (
  <section className="py-16 md:py-24 bg-gradient-to-br from-secondary via-ziah-brown-light to-secondary text-center">
    <div className="container mx-auto max-w-2xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-white mb-4">
          ZIAH não é apenas um evento.
        </h2>
        <p className="text-white/80 text-lg mb-3">
          É um divisor de águas. É posicionamento. É clareza. É conexão entre mulheres que decidiram crescer.
        </p>
        <p className="text-primary font-bold text-xl mb-8">
          1º Lote · R$ 527,80 ou 12x de R$ 60,05
        </p>
        <CtaButton text="COMPRAR MEU INGRESSO AGORA" />
      </motion.div>
    </div>
  </section>
);

export default FinalCtaSection;
