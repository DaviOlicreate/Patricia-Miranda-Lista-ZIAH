import { motion } from "framer-motion";

const speakers = [
  { name: "Patrícia Miranda", role: "Idealizadora do ZIAH, CEO MDX Eventos" },
  { name: "Thayná Deps", role: "Empresária" },
  { name: "Gleci Carvalho", role: "CEO GC Company" },
  { name: "Amanda Pinatto", role: "Médica Dermatologista" },
];

const SpeakersSection = () => {
  return (
    <section className="py-16 md:py-20 bg-ziah-warm-bg overflow-hidden">
      <div className="container mx-auto">
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary text-center mb-12">
          Conheça quem vai guiar essa experiência
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {speakers.map((s, i) => (
            <motion.div
              key={s.name}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl overflow-hidden group"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <div className="h-72 bg-gradient-to-br from-secondary to-ziah-brown-light flex items-center justify-center text-white/30 text-6xl">
                👩
              </div>
              <div className="p-5 text-center">
                <h3 className="font-serif text-lg font-bold text-secondary">{s.name}</h3>
                <p className="text-primary font-semibold text-sm mt-1">{s.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SpeakersSection;
