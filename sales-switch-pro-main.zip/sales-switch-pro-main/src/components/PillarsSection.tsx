import { motion } from "framer-motion";
import CtaButton from "./CtaButton";

const pillars = [
  { title: "Conexões Genuínas", desc: "Networking real com mulheres de diversas áreas em um ambiente acolhedor.", emoji: "🤝" },
  { title: "Inspiração & Estratégia", desc: "Ferramentas práticas para alinhar sua carreira e negócios com seu propósito.", emoji: "🎯" },
  { title: "Impacto Social", desc: "Apoiamos a ACAE. Sua presença não só te evolui, como transforma vidas.", emoji: "💛" },
];

const PillarsSection = () => {
  return (
    <section className="py-16 md:py-20">
      <div className="container mx-auto text-center">
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary mb-12">
          Por que você precisa estar no ZIAH?
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {pillars.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 }}
              className="relative h-72 rounded-lg overflow-hidden bg-gradient-to-t from-secondary via-secondary/80 to-secondary/40 flex flex-col justify-end p-8 text-left group hover:scale-[1.02] transition-transform"
            >
              <span className="text-4xl mb-3">{p.emoji}</span>
              <h3 className="font-serif text-xl font-bold text-primary mb-2">{p.title}</h3>
              <p className="text-white/90 text-sm">{p.desc}</p>
            </motion.div>
          ))}
        </div>

        <CtaButton text="QUERO VIVER ESSA EXPERIÊNCIA" />
      </div>
    </section>
  );
};

export default PillarsSection;
