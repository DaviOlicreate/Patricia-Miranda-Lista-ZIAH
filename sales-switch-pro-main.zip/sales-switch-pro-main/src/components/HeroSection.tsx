import { ChevronDown } from "lucide-react";
import { motion } from "framer-motion";
import heroBg from "@/assets/hero-bg.jpg";
import CtaButton from "./CtaButton";

const HeroSection = () => {
  return (
    <section
      className="relative min-h-screen flex items-center"
      style={{
        backgroundImage: `linear-gradient(to right, rgba(20,10,5,0.88), rgba(74,44,42,0.6)), url(${heroBg})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center py-10 lg:py-0">
        {/* Left - Copy */}
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center lg:text-left"
        >
          <div className="inline-flex flex-wrap gap-3 bg-white/10 backdrop-blur-md px-5 py-2.5 rounded-full border border-white/20 mb-6 text-sm font-medium text-orange-100 tracking-wide">
            <span className="flex items-center gap-1.5">📅 11 e 12 de Abril</span>
            <span className="flex items-center gap-1.5">📍 Hotel Quinta das Águas</span>
            <span className="flex items-center gap-1.5">🔥 Vagas Limitadas</span>
          </div>

          <h1 className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-5">
            Um encontro para mulheres que decidiram viver com{" "}
            <span className="text-primary italic">propósito, direção e posicionamento.</span>
          </h1>
          <p className="text-lg text-white/90 mb-8 max-w-xl">
            Dois dias de conexão, crescimento, estratégia e transformação real. 2ª Edição do ZIAH em Jacutinga/MG.
          </p>

          <div
            className="hidden lg:inline-flex flex-col items-center cursor-pointer text-primary"
            onClick={() => document.getElementById("video-section")?.scrollIntoView({ behavior: "smooth" })}
          >
            <ChevronDown size={48} className="animate-arrow-pulse" />
            <ChevronDown size={48} className="animate-arrow-pulse -mt-8" style={{ animationDelay: "1s" }} />
          </div>
        </motion.div>

        {/* Right - CTA Card */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="bg-card rounded-2xl p-8 md:p-10 border-t-4 border-primary max-w-md mx-auto lg:mr-0"
          style={{ boxShadow: "var(--shadow-float)" }}
        >
          <h3 className="font-serif text-2xl font-bold text-secondary text-center mb-3">
            Garante seu Ingresso Agora
          </h3>
          <p className="text-muted-foreground text-center text-sm mb-6">
            Vagas limitadas para a 2ª edição. Não fique de fora dessa experiência transformadora.
          </p>

          <div className="space-y-4 mb-6">
            <div className="flex items-center gap-3 text-sm text-foreground">
              <span className="text-primary text-lg">✓</span>
              <span>Palestras com mulheres referência</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-foreground">
              <span className="text-primary text-lg">✓</span>
              <span>Networking exclusivo e acolhedor</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-foreground">
              <span className="text-primary text-lg">✓</span>
              <span>Experiência completa com coffee break</span>
            </div>
            <div className="flex items-center gap-3 text-sm text-foreground">
              <span className="text-primary text-lg">✓</span>
              <span>Certificado de participação</span>
            </div>
          </div>

          <CtaButton text="QUERO GARANTIR MEU INGRESSO" />

          <p className="text-xs text-muted-foreground text-center mt-4 flex items-center justify-center gap-1">
            🔒 Compra segura via Sympla
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default HeroSection;
