import { motion } from "framer-motion";

const items = [
  { emoji: "🎤", title: "Mentorias Exclusivas", desc: "Com Patrícia Miranda e convidadas especiais" },
  { emoji: "🎁", title: "Kit Personalizado", desc: "Material exclusivo para participantes" },
  { emoji: "📖", title: "Apostila Impressa", desc: "Conteúdo completo do evento" },
  { emoji: "📱", title: "E-book Digital", desc: "Material de apoio para continuar evoluindo" },
  { emoji: "☕", title: "2 Coffee Breaks", desc: "Momentos de networking e conexão" },
  { emoji: "💧", title: "Água e Café", desc: "Liberados durante todas as palestras" },
];

const IncludesSection = () => {
  return (
    <section className="py-16 md:py-24">
      <div className="container mx-auto text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-primary font-bold text-sm uppercase tracking-widest">Tudo incluso</span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary mt-3 mb-12">
            O Pacote ZIAH inclui
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
          {items.map((item, i) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-card rounded-2xl p-6 text-center border border-border hover:border-primary/30 transition-colors"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <span className="text-4xl block mb-3">{item.emoji}</span>
              <h3 className="font-serif text-base font-bold text-secondary mb-1">{item.title}</h3>
              <p className="text-muted-foreground text-xs">{item.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default IncludesSection;
