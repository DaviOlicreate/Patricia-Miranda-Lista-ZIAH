import { motion } from "framer-motion";

const VideoSection = () => {
  return (
    <section id="video-section" className="py-16 md:py-20 bg-ziah-warm-bg">
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary mb-5">
            Veja como foi a última edição e sinta a energia do ZIAH.
          </h2>
          <p className="text-muted-foreground text-lg">
            Uma atmosfera única criada para potencializar seus resultados e renovar suas forças.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative pb-[56.25%] h-0 bg-secondary rounded-2xl overflow-hidden"
          style={{ boxShadow: "var(--shadow-card)" }}
        >
          <div className="absolute inset-0 flex items-center justify-center text-white/50 text-lg">
            🎬 Vídeo institucional
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default VideoSection;
