const MarqueeSection = () => {
  const text = "ZIAH 2ª EDIÇÃO • LUZ E ESPLENDOR • MULHERES IMPARÁVEIS • ESTRATÉGIA E PROPÓSITO • VAGAS LIMITADAS • GARANTA SEU INGRESSO • ";

  return (
    <div className="bg-primary text-primary-foreground py-4 overflow-hidden whitespace-nowrap relative">
      <div className="inline-block animate-marquee">
        <span className="inline-block px-10 font-sans font-bold text-base tracking-widest uppercase">{text}</span>
        <span className="inline-block px-10 font-sans font-bold text-base tracking-widest uppercase">{text}</span>
      </div>
    </div>
  );
};

export default MarqueeSection;
