import { motion } from "framer-motion";

const testimonials = [
  {
    name: "ERICA ALVES",
    text: "\"Participar do Ziah para mim foi viver um encontro marcado por Deus, nada ali foi por acaso. Desde o primeiro momento, vendo todo o cuidado com a decoração senti a presença d'Ele conduzindo cada detalhe, cada palavra e cada conexão entre mulheres, foi algo diferente!\"",
  },
  {
    name: "ELISANGELA E ELAINE",
    text: "\"O Ziah é conexão real, troca verdadeira, acolhimento e muita energia boa. A gente se sentiu profundamente conectada, inspirada e envolvida por cada detalhe. Saímos de lá apaixonadas, com o coração cheio, leves, renovadas e super realizadas.\"",
  },
  {
    name: "FERNANDA LAGO",
    text: "\"Foi uma honra imensa participar de um evento tão especial e cheio de propósito como o Ziah. Um evento impecável, cheio de amor em cada etapa. A palestra foi profunda e inspiradora, repleta de sabedoria e reflexões.\"",
  },
  {
    name: "DAYANE ARAÚJO",
    text: "\"Além de ser um momento muito agradável, por estar com outras mulheres com vivências e desafios parecidos, foi um espaço de troca e inspiração muito valiosa. A estrutura do evento estava impecável, tudo pensado com muito carinho. 🧡\"",
  },
];

const TestimonialsSection = () => {
  const doubled = [...testimonials, ...testimonials];

  return (
    <section className="py-16 md:py-20 text-center overflow-hidden">
      <div className="container mx-auto mb-12">
        <motion.span
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="block text-primary font-bold uppercase tracking-[3px] text-sm mb-3"
        >
          +500 MULHERES ESPERADAS
        </motion.span>
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary">
          O Ponto de Encontro da Mulher Empreendedora
        </h2>
      </div>

      <div className="relative">
        {/* Fade edges */}
        <div className="absolute left-0 top-0 bottom-0 w-24 md:w-36 bg-gradient-to-r from-background to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-24 md:w-36 bg-gradient-to-l from-background to-transparent z-10 pointer-events-none" />

        <div className="flex gap-8 w-max animate-scroll-testimonials hover:[animation-play-state:paused]">
          {doubled.map((t, i) => (
            <div
              key={i}
              className="w-[400px] flex-shrink-0 bg-ziah-warm-bg p-8 rounded-lg text-center transition-transform hover:-translate-y-1"
            >
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-5 text-2xl">
                ✨
              </div>
              <p className="font-serif italic text-foreground/80 mb-4 text-sm leading-relaxed">{t.text}</p>
              <p className="font-bold text-sm text-secondary">{t.name}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
