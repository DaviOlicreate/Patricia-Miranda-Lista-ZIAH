const Footer = () => (
  <footer className="bg-secondary py-8 text-center">
    <div className="container mx-auto">
      <p className="text-white/60 text-sm">&copy; 2025 ZIAH Eventos. Todos os direitos reservados.</p>
    </div>
  </footer>
);

export default Footer;
