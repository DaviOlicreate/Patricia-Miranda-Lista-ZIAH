const SYMPLA_URL = "https://www.sympla.com.br/evento/ziah/3329366";

export const CtaButton = ({ text = "GARANTIR MEU INGRESSO", className = "" }: { text?: string; className?: string }) => (
  <a
    href={SYMPLA_URL}
    target="_blank"
    rel="noopener noreferrer"
    className={`inline-block w-full max-w-md text-center font-sans font-bold uppercase tracking-wide
      bg-primary text-primary-foreground py-4 px-8 rounded-lg
      transition-all duration-300 hover:-translate-y-0.5
      animate-pulse-cta hover:bg-ziah-orange-dark
      text-base md:text-lg no-underline cursor-pointer ${className}`}
  >
    {text}
  </a>
);

export default CtaButton;
