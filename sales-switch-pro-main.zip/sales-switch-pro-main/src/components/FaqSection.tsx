import { useState } from "react";
import { ChevronDown } from "lucide-react";
import { motion } from "framer-motion";

const faqs = [
  {
    q: "Como funciona a compra do ingresso?",
    a: "A compra é feita de forma segura pela plataforma Sympla. Após o pagamento, você receberá a confirmação por e-mail e será adicionada ao grupo exclusivo de participantes.",
  },
  {
    q: "Onde será o evento?",
    a: "O evento acontecerá presencialmente na região de Jacutinga-MG / Itapira-SP. O endereço exato será enviado no grupo exclusivo após a confirmação da compra.",
  },
  {
    q: "Posso levar acompanhante?",
    a: "Sim! Porém cada ingresso é individual. Compartilhe esta página para que sua convidada também garanta o dela.",
  },
  {
    q: "O ingresso inclui o quê?",
    a: "O ingresso garante acesso completo ao evento: todas as palestras, networking, coffee break e certificado de participação.",
  },
];

const FaqSection = () => {
  const [active, setActive] = useState<number | null>(null);

  return (
    <section className="py-16 md:py-20 bg-ziah-warm-bg">
      <div className="container mx-auto max-w-3xl">
        <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary text-center mb-10">
          Perguntas Frequentes
        </h2>

        <div className="space-y-4">
          {faqs.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="bg-card rounded-lg overflow-hidden shadow-sm"
            >
              <button
                onClick={() => setActive(active === i ? null : i)}
                className="w-full flex justify-between items-center p-5 text-left font-semibold text-secondary hover:bg-muted/50 transition-colors"
              >
                {f.q}
                <ChevronDown
                  size={20}
                  className={`text-primary transition-transform ${active === i ? "rotate-180" : ""}`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  active === i ? "max-h-40 pb-5 px-5" : "max-h-0"
                }`}
              >
                <p className="text-muted-foreground text-sm">{f.a}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FaqSection;
