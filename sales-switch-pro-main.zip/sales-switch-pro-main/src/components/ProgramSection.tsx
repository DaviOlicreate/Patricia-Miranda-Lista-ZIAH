import { motion } from "framer-motion";

const saturday = [
  { time: "08:00 – 09:00", title: "Credenciamento & Welcome Coffee", desc: "Recepção das participantes, entrega do kit personalizado e networking inicial." },
  { time: "09:00 – 10:00", title: "Abertura Oficial – Patrícia Miranda", desc: "Apresentação do propósito do ZIAH, visão da 2ª edição e direcionamento estratégico do evento." },
  { time: "10:00 – 10:30", title: "Coffee Break", desc: "" },
  { time: "10:30 – 12:30", title: "Talk Show – 6 Grandes Mulheres", desc: "Histórias reais de liderança, empreendedorismo, posicionamento e construção de autoridade." },
  { time: "12:30 – 14:30", title: "Intervalo para Almoço", desc: "" },
  { time: "14:30 – 16:30", title: "Mentoria Estratégica com Patrícia Miranda", desc: "Vendas de Alto Valor · Direcionamento de Propósito · Fidelização e Experiência do Cliente. Com 22 anos de experiência conduzindo contas milionárias." },
  { time: "17:00 – 19:00", title: "Talk Show – Histórias de Desafios e Superação", desc: "Mulheres que transformaram dor em força, crise em crescimento e desafios em legado." },
];

const sunday = [
  { time: "09:00 – 10:00", title: "Aula de Alongamento & Conexão", desc: "Experiência sensorial para alinhar corpo, mente e espírito." },
  { time: "11:00 – 13:00", title: "Mentoria Final & Direcionamento Prático", desc: "Encerramento com ativação estratégica, plano de ação e alinhamento de próximos passos." },
];

const TimelineItem = ({ item, index }: { item: typeof saturday[0]; index: number }) => (
  <motion.div
    initial={{ opacity: 0, x: -20 }}
    whileInView={{ opacity: 1, x: 0 }}
    viewport={{ once: true }}
    transition={{ delay: index * 0.08 }}
    className="flex gap-4 md:gap-6"
  >
    <div className="flex flex-col items-center">
      <div className="w-3 h-3 rounded-full bg-primary shrink-0 mt-1.5" />
      {index < 6 && <div className="w-0.5 flex-1 bg-primary/20" />}
    </div>
    <div className="pb-6">
      <span className="text-xs font-bold text-primary tracking-wider uppercase">{item.time}</span>
      <h4 className="font-serif text-lg font-bold text-secondary mt-1">{item.title}</h4>
      {item.desc && <p className="text-muted-foreground text-sm mt-1">{item.desc}</p>}
    </div>
  </motion.div>
);

const ProgramSection = () => {
  return (
    <section className="py-16 md:py-24 bg-ziah-warm-bg">
      <div className="container mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-14"
        >
          <span className="text-primary font-bold text-sm uppercase tracking-widest">Programação Oficial</span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary mt-3">
            Dois dias de imersão e transformação
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Saturday */}
          <div>
            <div className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground px-5 py-2 rounded-full mb-8 font-bold text-sm">
              📅 Sábado – 11 de Abril
            </div>
            <div className="space-y-0">
              {saturday.map((item, i) => (
                <TimelineItem key={item.title} item={item} index={i} />
              ))}
            </div>
          </div>

          {/* Sunday */}
          <div>
            <div className="inline-flex items-center gap-2 bg-secondary text-secondary-foreground px-5 py-2 rounded-full mb-8 font-bold text-sm">
              📅 Domingo – 12 de Abril
            </div>
            <div className="space-y-0">
              {sunday.map((item, i) => (
                <TimelineItem key={item.title} item={item} index={i} />
              ))}
            </div>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="mt-10 bg-card rounded-2xl p-6 border border-border"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <h4 className="font-serif text-lg font-bold text-secondary mb-2">🏨 Hospedagem & Alimentação</h4>
              <p className="text-muted-foreground text-sm">
                Hospedagem e alimentação são por conta de cada participante. O Hotel Quinta das Águas oferece opção de pensão completa para uma experiência ainda mais imersiva.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProgramSection;
