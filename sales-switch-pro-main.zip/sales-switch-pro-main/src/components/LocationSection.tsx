import { MapPin } from "lucide-react";
import { motion } from "framer-motion";

const LocationSection = () => {
  return (
    <section className="py-16 bg-secondary text-secondary-foreground">
      <div className="container mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="h-64 lg:h-80 rounded-2xl bg-ziah-brown-light/50 flex items-center justify-center text-white/30 text-lg border-2 border-white/10"
        >
          📷 Foto do local
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="text-center lg:text-left"
        >
          <MapPin size={48} className="text-primary mb-5 mx-auto lg:mx-0" />
          <h2 className="font-serif text-3xl font-bold text-primary mb-3">Itapira/SP - Jacutinga / MG</h2>
          <p className="text-white/80">
            Local exato será enviado no grupo exclusivo de participantes após a compra do ingresso.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default LocationSection;
