import { motion } from "framer-motion";
import CtaButton from "./CtaButton";

const PricingSection = () => {
  return (
    <section className="py-16 md:py-24 bg-ziah-warm-bg">
      <div className="container mx-auto max-w-lg text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-primary font-bold text-sm uppercase tracking-widest">Investimento</span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-secondary mt-3 mb-10">
            Garanta sua vaga agora
          </h2>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="bg-card rounded-2xl p-8 md:p-10 border-t-4 border-primary relative overflow-hidden"
          style={{ boxShadow: "var(--shadow-float)" }}
        >
          <div className="absolute top-4 right-4 bg-primary text-primary-foreground text-xs font-bold px-3 py-1 rounded-full">
            1º LOTE
          </div>

          <h3 className="font-serif text-2xl font-bold text-secondary mb-1">ZIAH – 2ª Edição</h3>
          <p className="text-muted-foreground text-sm mb-6">11 e 12 de Abril · Hotel Quinta das Águas</p>

          <div className="mb-2">
            <span className="font-serif text-5xl font-bold text-secondary">R$ 527</span>
            <span className="font-serif text-2xl font-bold text-secondary">,80</span>
          </div>
          <p className="text-muted-foreground text-sm mb-1">+ R$ 52,78 taxa da plataforma</p>
          <p className="text-primary font-bold text-sm mb-8">
            ou em até <span className="text-lg">12x de R$ 60,05</span>
          </p>

          <div className="space-y-3 text-left mb-8">
            {[
              "Mentorias exclusivas com Patrícia Miranda",
              "Talk Shows com grandes mulheres",
              "Kit personalizado + apostila + e-book",
              "2 Coffee Breaks inclusos",
              "Certificado de participação",
            ].map((item) => (
              <div key={item} className="flex items-center gap-3 text-sm text-foreground">
                <span className="text-primary text-lg shrink-0">✓</span>
                <span>{item}</span>
              </div>
            ))}
          </div>

          <CtaButton text="COMPRAR MEU INGRESSO" />
          <p className="text-xs text-muted-foreground text-center mt-4 flex items-center justify-center gap-1">
            🔒 Compra segura via Sympla · Vagas limitadas
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default PricingSection;
